package bg.crm.integration.productos.services.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bg.crm.integration.productos.controller.dtos.ProductosDto;
import bg.crm.integration.productos.repository.contract.IProductoRepository;
import bg.crm.integration.productos.services.contract.IProductosService;

@Service
public class ProductosService implements IProductosService{
    @Autowired
    IProductoRepository _productosRepository;

    @Override
    public List<ProductosDto> findAll() {
        return _productosRepository.findAll();
    }

    @Override
    public ProductosDto findById(long id) {
        return _productosRepository.findById(id);
    }

    @Override
    public ProductosDto save(ProductosDto productosDto) {
        return _productosRepository.save(productosDto);
    }

    @Override
    public void delete(long id) {
        _productosRepository.delete(id);
    }

    @Override
    public ProductosDto update(ProductosDto productosDto) {
        return _productosRepository.update(productosDto);
    }

}
