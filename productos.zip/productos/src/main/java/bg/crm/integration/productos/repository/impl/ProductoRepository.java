package bg.crm.integration.productos.repository.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import bg.crm.integration.productos.controller.dtos.ProductosDto;
import bg.crm.integration.productos.repository.contract.IProductoRepository;

@Repository
public class ProductoRepository implements IProductoRepository{
    public final List<ProductosDto> productosList = new ArrayList<>();
    
    public ProductoRepository() {
        generarDatos();
    }

    private void generarDatos() {
        productosList.add(new ProductosDto(2, "Producto B", "Descripción B", 2, 2, 2, "Modelo B", "Azul", 15, 200.75, 50));
        productosList.add(new ProductosDto(3, "Producto C", "Descripción C", 3, 3, 3, "Modelo C", "Verde", 20, 300.00, 100));
        productosList.add(new ProductosDto(1, "Producto A", "Descripción A", 1, 1, 1, "Modelo A", "Rojo", 10, 100.50, 20));
    }

    @Override
    public List<ProductosDto> findAll() {
        return productosList;
    }

    @Override
    public ProductosDto findById(long id) {
        return productosList.stream()
                .filter(producto -> producto.getId() == id)
                .findFirst()
                .orElse(null);
    }

    @Override
    public ProductosDto save(ProductosDto productosDto) {
        var id = productosList.size() + 1;
        productosDto.setId(id);
        productosList.add(productosDto);
        return productosDto;
    }

    @Override
    public void delete(long id) {
        productosList.removeIf(producto -> producto.getId() == id);
    }

    @Override
    public ProductosDto update(ProductosDto productosDto) {
       return productosList.stream()
                .filter(producto -> producto.getId() == productosDto.getId())
                .findFirst()
                .map(producto -> {
                    producto.setNombre(productosDto.getNombre());
                    producto.setDescripcion(productosDto.getDescripcion());
                    producto.setIdCategoria(productosDto.getIdCategoria());
                    producto.setIdMarca(productosDto.getIdMarca());
                    producto.setModelo(productosDto.getModelo());
                    producto.setColor(productosDto.getColor());
                    producto.setPrecio(productosDto.getPrecio());
                    return producto;
                })
                .orElse(null);
    }

}
