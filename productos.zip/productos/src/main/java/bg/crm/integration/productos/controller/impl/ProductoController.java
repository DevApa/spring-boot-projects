package bg.crm.integration.productos.controller.impl;

import org.slf4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import bg.crm.integration.productos.controller.contract.IProductosController;
import bg.crm.integration.productos.controller.dtos.ProductosDto;
import bg.crm.integration.productos.services.contract.IProductosService;
import bg.crm.integration.productos.utils.constants.ErrorConfig;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@Tag(name = "Productos", description = "Controlador de productos")
public class ProductoController implements IProductosController {
    
    private final IProductosService productosService;
    private final Logger log = org.slf4j.LoggerFactory.getLogger(ProductoController.class);

    public ProductoController(IProductosService productosService) {
        this.productosService = productosService;
    }

    @Override
    public ResponseEntity<?> getAllProductos() {
        try {
            var productos = productosService.findAll();
            if (productos.isEmpty()) {
                return ResponseEntity.status(404).body(ErrorConfig.ERROR_PRODUCTO_LIST_NO_CONTENT);
            }
            log.info("Lista de productos: {}", productos);
            return ResponseEntity.ok(productos);
        } 
        catch (Exception e) {
            return ResponseEntity.status(500).body(ErrorConfig.ERROR_INTERNO_SERVIDOR + e.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> getProductoById(long id) {
        try {
            var producto = productosService.findById(id);
            if (producto == null) {
                return ResponseEntity.status(404).body(ErrorConfig.ERROR_PRODUCTO_NO_ENCONTRADO);
            }
            log.info("Producto encontrado: {}", producto);
            return ResponseEntity.ok(producto);
        } 
        catch (Exception e) {
            log.error("Error al obtener el producto por ID: {}", id, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ErrorConfig.ERROR_INTERNO_SERVIDOR + e.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> save(ProductosDto productoDto) {
        try {
            var producto = productosService.save(productoDto);
            if (producto == null) {
                return ResponseEntity.status(400).body(ErrorConfig.ERROR_PRODUCTO_SAVE);
            }
            log.info("Producto guardado: {}", producto);
            return ResponseEntity.status(201).body(producto);
        } 
        catch (Exception e) {
            log.error("Error al guardar el producto: {}", productoDto, e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ErrorConfig.ERROR_INTERNO_SERVIDOR + e.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> update(ProductosDto productoDto) {
        try {
            var producto = productosService.findById(productoDto.getId());
            if (producto == null) {
                return ResponseEntity.status(404).body(ErrorConfig.ERROR_PRODUCTO_NO_ENCONTRADO);
            }
            var updateProducto = productosService.update(productoDto);
            if (updateProducto == null) {
                return ResponseEntity.status(404).body(ErrorConfig.ERROR_PRODUCTO_UPDATE);
            }
            log.info("Producto actualizado: {}", updateProducto);
            return ResponseEntity.ok(updateProducto);
        } 
        catch (Exception e) {
            log.error("Error al actualizar el producto: {}", productoDto, e);
            return ResponseEntity.status(500).body(ErrorConfig.ERROR_INTERNO_SERVIDOR + e.getMessage());
        }
    }

    @Override
    public ResponseEntity<?> delete(long id) {
        try {
            var producto = productosService.findById(id);
            if (producto == null) {
                return ResponseEntity.status(404).body("Producto no encontrado");
            }
            productosService.delete(id);
            return ResponseEntity.status(204).build();
        } 
        catch (Exception e) {
            log.error("Error al eliminar el producto con ID: {}", id, e);
            return ResponseEntity.status(500).body("Error al eliminar el producto: " + e.getMessage());
        }
    }

}
