package bg.crm.integration.productos.utils.constants;

public class ErrorConfig {
    private ErrorConfig() { 
        // default implementation ignored
    }

    public static final String ERROR_PRODUCTO_NOT_FOUND = "Producto no encontrado";
    public static final String ERROR_PRODUCTO_ID_INVALIDO = "ID de producto inválido";
    public static final String ERROR_PRODUCTO_LIST_NO_CONTENT = "No hay productos disponibles";
    public static final String ERROR_PRODUCTO_ID_NO_ENCONTRADO = "ID de producto no encontrado";
    public static final String ERROR_PRODUCTO_SAVE = "Error al guardar el producto";
    public static final String ERROR_PRODUCTO_UPDATE = "Error al actualizar el producto";
    public static final String ERROR_PRODUCTO_DELETE = "Error al eliminar el producto";
    public static final String ERROR_PRODUCTO_LIST = "Error al listar los productos";
    public static final String ERROR_PRODUCTO_NO_ENCONTRADO = "Producto no encontrado";
    public static final String ERROR_INTERNO_SERVIDOR = "Ocurrió un error interno en el servidor";
}