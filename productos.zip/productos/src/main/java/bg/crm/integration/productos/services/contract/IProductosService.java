package bg.crm.integration.productos.services.contract;

import java.util.List;

import bg.crm.integration.productos.controller.dtos.ProductosDto;

public interface IProductosService {
    List<ProductosDto> findAll();
    ProductosDto findById(long id);
    ProductosDto save(ProductosDto productosDto);
    void delete(long id);
    ProductosDto update(ProductosDto productosDto);
}
