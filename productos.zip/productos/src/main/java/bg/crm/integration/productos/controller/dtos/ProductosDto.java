package bg.crm.integration.productos.controller.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class ProductosDto {
    private long id;
    private String nombre;
    private String descripcion;
    private int idCategoria;
    private int idSubcategoria;
    private int idMarca;
    private String modelo;
    private String color;
    private int tamano;
    private Double precio;
    private long stock;
}
